pphp
prog -> php
pphp_run