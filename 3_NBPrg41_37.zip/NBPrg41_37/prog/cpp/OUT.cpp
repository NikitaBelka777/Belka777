/* Nikita Beloshenko (GNU) 2013,2014 */

/* OUT.CPP */

#include <stdio.h>
#include "OUT.h"

int main()
{
  float x,y;

  x = 1; y = Poly(x);

  printf ("x = %4.2f; y = Poly(x) = %4.2f", x , y);

  return 0;
}

